"""Запуск: python demo_simulation.py"""
from support_platform import generate_demo


def main():
    platform = generate_demo(chat_count=120, seed=42)
    platform.update_user(1, city='Самара')
    platform.update_operator(1, experience_years=9)
    print('Создано пользователей:', len(platform.users))
    print('Создано операторов:', len(platform.operators))
    print('Создано чатов:', len(platform.chats))
    for status in ('waiting', 'open', 'closed'):
        print(status, sum(chat.status == status for chat in platform.chats.values()))
    print('С оценкой:', sum(chat.csat is not None for chat in platform.chats.values()))
    print('Пример переписки:', platform.chats[1].to_dict())


if __name__ == '__main__':
    main()
