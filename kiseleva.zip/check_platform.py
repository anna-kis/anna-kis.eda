"""Проверка основных правил: python check_platform.py. Только собственный модуль."""
from support_platform import ChatPlatform, ModelClock, generate_demo, _json


def rejects(action):
    try:
        action()
    except ValueError:
        return
    raise AssertionError('Ожидался ValueError')


def main():
    profile = dict(full_name='Иван Иванович Иванов', city='Пермь',
                   birth_date='1990-02-28', position='Инженер', experience_years=5)
    p = ChatPlatform()
    user = p.add_user(**profile)
    other = p.add_user(**profile)
    first = p.create_chat(user.id, 'Вопрос "с кавычками"\nи переносом')
    assert first.status == 'waiting'
    operator = p.add_operator(**profile)
    assert first.status == 'open' and first.operator_id == operator.id
    second = p.create_chat(other.id, 'Ещё вопрос')
    assert second.status == 'waiting'
    rejects(lambda: p.rate_chat(user.id, first.id, 5))
    rejects(lambda: p.send_user_message(other.id, first.id, 'Чужой чат'))
    rejects(lambda: p.reply(operator.id, second.id, 'Не назначен'))
    rejects(lambda: p.reply(operator.id, first.id, ' '))
    p.reply(operator.id, first.id, 'Ответ')
    p.close_chat(operator.id, first.id)
    assert second.status == 'open' and second.operator_id == operator.id
    rejects(lambda: p.close_chat(operator.id, first.id))
    rejects(lambda: p.reply(operator.id, first.id, 'Уже закрыт'))
    rejects(lambda: p.send_user_message(user.id, first.id, 'Уже закрыт'))
    rejects(lambda: p.rate_chat(other.id, first.id, 5))
    for invalid in (0, 6, True, 1.5, '5'):
        rejects(lambda: p.rate_chat(user.id, first.id, invalid))
    p.rate_chat(user.id, first.id, 5)
    rejects(lambda: p.rate_chat(user.id, first.id, 4))
    rejects(lambda: p.update_user(user.id, city='Москва', birth_date='2023-02-29'))
    assert user.city == 'Пермь'  # Ошибка не приводит к частичному обновлению.
    p.update_user(user.id, city='Казань', birth_date='1992-02-29')
    assert user.city == 'Казань'
    rejects(lambda: p.update_operator(operator.id, experience_years=-1))
    rejects(lambda: p.create_chat(999, 'Нет пользователя'))
    rejects(lambda: p.update_user(user.id, id=99))
    snapshot = first.to_dict()
    snapshot['messages'][0]['text'] = 'Изменённая копия'
    assert first.messages[0]['text'] != 'Изменённая копия'
    assert _json('"\\\n\t\x00') == '"\\"\\\\\\u000a\\u0009\\u0000"'
    clock = ModelClock('2024-02-28')
    clock.seconds = 86399
    assert clock.tick() == '2024-02-28T23:59:59'
    assert clock.tick() == '2024-02-29T00:00:00'
    for seed in (1, 42, 999):
        demo = generate_demo(120, seed)
        assert len(demo.chats) == 120
        assert sum(c.status == 'closed' for c in demo.chats.values()) == 108
        assert sum(c.status == 'waiting' for c in demo.chats.values()) == 6
        assert sum(c.csat is not None for c in demo.chats.values()) == 72
        active = [c.operator_id for c in demo.chats.values() if c.status == 'open']
        assert len(active) == len(set(active)) == 6
        for chat in demo.chats.values():
            times = [m['sent_at'] for m in chat.messages]
            assert times == sorted(times)
            assert all(chat.created_at <= t for t in times)
            if chat.closed_at:
                assert all(t <= chat.closed_at for t in times)
    assert generate_demo().chats[1].to_dict() == generate_demo().chats[1].to_dict()
    print('Все проверки пройдены.')


if __name__ == '__main__':
    main()
