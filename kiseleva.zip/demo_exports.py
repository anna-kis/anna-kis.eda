"""Запуск: python demo_exports.py. JSON сохраняются в текущую папку."""
from support_platform import generate_demo


def main():
    platform = generate_demo(chat_count=120, seed=42)
    platform.export_chats('all_chats.json')
    platform.export_chats('operator_1_chats.json', operator_id=1)
    platform.export_chats('user_1_chats.json', user_id=1)
    platform.export_chats('operator_1_user_1_chats.json', operator_id=1, user_id=1)
    platform.export_profiles('all_profiles.json')
    platform.export_profiles('operators.json', role='operator')
    platform.export_profiles('users.json', role='user')


if __name__ == '__main__':
    main()
