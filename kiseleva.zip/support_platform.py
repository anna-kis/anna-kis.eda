"""Модель поддержки. Внешние и стандартные библиотеки не импортируются."""


class RandomGenerator:
    """Воспроизводимый генератор для симуляции, не для криптографии."""

    def __init__(self, seed=42):
        if type(seed) is not int:
            raise ValueError("seed должен быть целым числом")
        self.state = seed % 2147483647 or 1

    def randint(self, minimum, maximum):
        if type(minimum) is not int or type(maximum) is not int or minimum > maximum:
            raise ValueError("Некорректный диапазон")
        self.state = self.state * 48271 % 2147483647
        return minimum + self.state % (maximum - minimum + 1)

    def choice(self, values):
        if not values:
            raise ValueError("Нельзя выбрать из пустого списка")
        return values[self.randint(0, len(values) - 1)]


def _json(value):
    """Сериализация используемых типов в JSON, включая управляющие символы."""
    if value is None:
        return "null"
    if type(value) is bool:
        return "true" if value else "false"
    if type(value) is int:
        return str(value)
    if isinstance(value, str):
        result = '"'
        for char in value:
            if char in ('"', '\\'):
                result += '\\' + char
            elif ord(char) < 32 or 0xD800 <= ord(char) <= 0xDFFF:
                result += '\\u' + format(ord(char), '04x')
            else:
                result += char
        return result + '"'
    if isinstance(value, (list, tuple)):
        return '[' + ', '.join(_json(item) for item in value) + ']'
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise TypeError("Ключи JSON должны быть строками")
        return '{' + ', '.join(_json(k) + ': ' + _json(v) for k, v in value.items()) + '}'
    raise TypeError("Неподдерживаемый тип JSON")


def _date_parts(value):
    try:
        if not isinstance(value, str) or len(value) != 10 or value[4] != '-' or value[7] != '-':
            raise ValueError()
        year, month, day = (int(part) for part in value.split('-'))
        leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
        days = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if not 1 <= year <= 9999 or not 1 <= month <= 12 or not 1 <= day <= days[month - 1]:
            raise ValueError()
        if value != f'{year:04d}-{month:02d}-{day:02d}':
            raise ValueError()
        return year, month, day
    except (ValueError, TypeError):
        raise ValueError("Дата должна быть существующей датой YYYY-MM-DD") from None


class ModelClock:
    """Модельное время без доступа к системным часам. Шаг — одна секунда."""

    def __init__(self, start_date='2026-01-01'):
        self.year, self.month, self.day = _date_parts(start_date)
        self.seconds = 0

    def tick(self):
        stamp = (f'{self.year:04d}-{self.month:02d}-{self.day:02d}T'
                 f'{self.seconds // 3600:02d}:{self.seconds // 60 % 60:02d}:'
                 f'{self.seconds % 60:02d}')
        self.seconds += 1
        if self.seconds == 86400:
            self.seconds = 0
            leap = self.year % 4 == 0 and (self.year % 100 != 0 or self.year % 400 == 0)
            days = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
            self.day += 1
            if self.day > days[self.month - 1]:
                self.day = 1
                self.month += 1
                if self.month == 13:
                    self.month = 1
                    self.year += 1
        return stamp


class Profile:
    def __init__(self, profile_id, full_name, city, birth_date, position, experience_years):
        self.id = profile_id
        self.update(full_name=full_name, city=city, birth_date=birth_date,
                    position=position, experience_years=experience_years)

    def update(self, **changes):
        allowed = {'full_name', 'city', 'birth_date', 'position', 'experience_years'}
        if set(changes) - allowed:
            raise ValueError("Неизвестное поле профиля")
        for key, value in changes.items():
            if key == 'experience_years':
                if type(value) is not int or value < 0:
                    raise ValueError("Стаж должен быть целым неотрицательным числом")
            elif not isinstance(value, str) or not value.strip():
                raise ValueError("Текстовые поля не должны быть пустыми")
            if key == 'birth_date':
                _date_parts(value)
        for key, value in changes.items():
            setattr(self, key, value)

    def to_dict(self):
        return {key: getattr(self, key) for key in
                ('id', 'full_name', 'city', 'birth_date', 'position', 'experience_years')}


class User(Profile):
    """Профиль клиента; действия выполняются через ChatPlatform по его ID."""


class Operator(Profile):
    """Оператор обслуживает не более одного незакрытого чата."""


class Chat:
    def __init__(self, chat_id, user_id, created_at):
        self.id = chat_id
        self.user_id = user_id
        self.operator_id = None
        self.status = 'waiting'
        self.created_at = created_at
        self.closed_at = None
        self.csat = None
        self.messages = []

    def to_dict(self):
        return {'id': self.id, 'user_id': self.user_id, 'operator_id': self.operator_id,
                'status': self.status, 'created_at': self.created_at,
                'closed_at': self.closed_at, 'csat': self.csat,
                'messages': [dict(message) for message in self.messages]}


class ChatPlatform:
    def __init__(self, seed=42, start_date='2026-01-01'):
        self.users = {}
        self.operators = {}
        self.chats = {}
        self.random = RandomGenerator(seed)
        self.clock = ModelClock(start_date)

    def add_user(self, **profile):
        user = User(len(self.users) + 1, **profile)
        self.users[user.id] = user
        return user

    def add_operator(self, **profile):
        operator = Operator(len(self.operators) + 1, **profile)
        self.operators[operator.id] = operator
        self._assign_waiting()
        return operator

    @staticmethod
    def _get(collection, item_id):
        if type(item_id) is not int or item_id not in collection:
            raise ValueError("Объект с таким ID не найден")
        return collection[item_id]

    def update_user(self, user_id, **changes):
        self._get(self.users, user_id).update(**changes)

    def update_operator(self, operator_id, **changes):
        self._get(self.operators, operator_id).update(**changes)

    def _assign_waiting(self):
        busy = {chat.operator_id for chat in self.chats.values() if chat.status == 'open'}
        free = [operator_id for operator_id in self.operators if operator_id not in busy]
        for chat in self.chats.values():
            if not free:
                break
            if chat.status == 'waiting':
                chat.operator_id = self.random.choice(free)
                chat.status = 'open'
                free.remove(chat.operator_id)

    @staticmethod
    def _validate_text(text):
        if not isinstance(text, str) or not text.strip():
            raise ValueError("Сообщение не должно быть пустым")

    def _message(self, chat, role, sender_id, text):
        chat.messages.append({'sender_role': role, 'sender_id': sender_id,
                              'text': text, 'sent_at': self.clock.tick()})

    def create_chat(self, user_id, text):
        self._get(self.users, user_id)
        self._validate_text(text)
        chat = Chat(len(self.chats) + 1, user_id, self.clock.tick())
        self.chats[chat.id] = chat
        self._message(chat, 'user', user_id, text)
        self._assign_waiting()
        return chat

    def send_user_message(self, user_id, chat_id, text):
        self._get(self.users, user_id)
        chat = self._get(self.chats, chat_id)
        self._validate_text(text)
        if chat.user_id != user_id or chat.status == 'closed':
            raise ValueError("Нельзя написать в чужой или закрытый чат")
        self._message(chat, 'user', user_id, text)

    def _operator_chat(self, operator_id, chat_id):
        self._get(self.operators, operator_id)
        chat = self._get(self.chats, chat_id)
        if chat.operator_id != operator_id or chat.status != 'open':
            raise ValueError("Нужен открытый чат, назначенный этому оператору")
        return chat

    def reply(self, operator_id, chat_id, text):
        chat = self._operator_chat(operator_id, chat_id)
        self._validate_text(text)
        self._message(chat, 'operator', operator_id, text)

    def close_chat(self, operator_id, chat_id):
        chat = self._operator_chat(operator_id, chat_id)
        chat.status = 'closed'
        chat.closed_at = self.clock.tick()
        self._assign_waiting()

    def rate_chat(self, user_id, chat_id, csat):
        self._get(self.users, user_id)
        chat = self._get(self.chats, chat_id)
        if chat.user_id != user_id or chat.status != 'closed':
            raise ValueError("Оценить можно только свой закрытый чат")
        if type(csat) is not int or not 1 <= csat <= 5:
            raise ValueError("CSAT должен быть целым числом от 1 до 5")
        if chat.csat is not None:
            raise ValueError("Оценка уже выставлена")
        chat.csat = csat

    @staticmethod
    def _export(data, path):
        encoded = _json(data)
        with open(path, 'w', encoding='utf-8') as output:
            output.write(encoded + '\n')
        print(encoded)
        return data

    def export_chats(self, path, operator_id=None, user_id=None):
        """Оба фильтра одновременно означают пересечение условий."""
        if operator_id is not None:
            self._get(self.operators, operator_id)
        if user_id is not None:
            self._get(self.users, user_id)
        data = [chat.to_dict() for chat in self.chats.values()
                if (operator_id is None or chat.operator_id == operator_id)
                and (user_id is None or chat.user_id == user_id)]
        return self._export(data, path)

    def export_profiles(self, path, role=None):
        if role not in (None, 'user', 'operator'):
            raise ValueError("Роль должна быть user, operator или None")
        data = {}
        if role in (None, 'user'):
            data['users'] = [user.to_dict() for user in self.users.values()]
        if role in (None, 'operator'):
            data['operators'] = [operator.to_dict() for operator in self.operators.values()]
        return self._export(data, path)


def generate_demo(chat_count=120, seed=42):
    """Создать профили и чаты со всеми статусами и разными оценками."""
    if type(chat_count) is not int or chat_count < 100:
        raise ValueError("Демонстрация требует не менее 100 чатов")
    platform = ChatPlatform(seed)
    rng = platform.random
    first_names = ['Иван', 'Павел', 'Денис', 'Алексей', 'Сергей']
    last_names = ['Иванов', 'Петров', 'Сидоров', 'Смирнов', 'Козлов']
    patronymics = ['Иванович', 'Петрович', 'Сергеевич', 'Алексеевич']
    cities = ['Москва', 'Казань', 'Екатеринбург', 'Пермь', 'Тюмень']
    for role, count in (('operator', 6), ('user', 30)):
        for _ in range(count):
            profile = dict(
                full_name=rng.choice(last_names) + ' ' + rng.choice(first_names) + ' ' + rng.choice(patronymics),
                city=rng.choice(cities),
                birth_date=f'{rng.randint(1970, 2000):04d}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}',
                position='Оператор поддержки' if role == 'operator' else rng.choice(['Инженер', 'Учитель', 'Менеджер']),
                experience_years=rng.randint(0, 8))
            if role == 'operator':
                platform.add_operator(**profile)
            else:
                platform.add_user(**profile)
    questions = ['Не получается войти', 'Как изменить профиль?', 'Не приходит письмо', 'Где мой заказ?']
    for _ in range(chat_count):
        platform.create_chat(rng.choice(list(platform.users)), rng.choice(questions))
    # Оставляем 12 незакрытых обращений: 6 в работе и 6 в очереди.
    for index in range(chat_count - 12):
        chat = rng.choice([chat for chat in platform.chats.values() if chat.status == 'open'])
        platform.reply(chat.operator_id, chat.id, 'Здравствуйте! Уточните, когда возникла проблема.')
        platform.send_user_message(chat.user_id, chat.id, rng.choice(['Сегодня утром.', 'Вчера вечером.']))
        platform.reply(chat.operator_id, chat.id, 'Проблема устранена. Спасибо за обращение!')
        platform.close_chat(chat.operator_id, chat.id)
        if index % 3 != 0:
            platform.rate_chat(chat.user_id, chat.id, rng.randint(1, 5))
    for chat in platform.chats.values():
        if chat.status == 'open':
            platform.reply(chat.operator_id, chat.id, 'Здравствуйте! Проверяю ваше обращение.')
    return platform
